# Correctif Hero — stockage local VPS

Ce paquet concerne uniquement le Hero.

## Architecture finale

- Supabase reste utilisé pour les tables `hero_settings` et `hero_carousel_images`.
- Les nouveaux médias du Hero ne sont plus envoyés vers Supabase Storage.
- Les fichiers sont écrits localement dans :
  `/var/www/darlamamy/uploads/hero/images` et `/var/www/darlamamy/uploads/hero/videos`.
- L'URL publique reste `/uploads/hero/...`.
- Les anciennes URLs Supabase déjà présentes en base peuvent continuer à être lues par le frontend, mais les nouvelles créations/remplacements via l'admin doivent être locales.

## Variables optionnelles

Par défaut, si l'application tourne dans `/var/www/darlamamy/app`, le code utilise automatiquement `/var/www/darlamamy/uploads/hero`.

Pour forcer le chemin :

```env
HERO_UPLOAD_ROOT=/var/www/darlamamy/uploads/hero
```

## Dossiers et permissions VPS

```bash
sudo mkdir -p /var/www/darlamamy/uploads/hero/images
sudo mkdir -p /var/www/darlamamy/uploads/hero/videos
sudo chown -R sysadmin:www-data /var/www/darlamamy/uploads
sudo find /var/www/darlamamy/uploads -type d -exec chmod 755 {} \;
sudo find /var/www/darlamamy/uploads -type f -exec chmod 644 {} \;
```

Adapte `sysadmin:www-data` si PM2 tourne avec un autre utilisateur.

## Nginx

Dans le bloc `server` de `darlamamy.com` :

```nginx
client_max_body_size 60M;

location /uploads/hero/ {
    alias /var/www/darlamamy/uploads/hero/;
    expires 30d;
    add_header Cache-Control "public, max-age=2592000";
    try_files $uri =404;
}
```

Puis :

```bash
sudo nginx -t
sudo systemctl reload nginx
```

La route Next.js `/uploads/hero/[category]/[filename]` est conservée pour le développement ou comme fallback, mais en production Nginx peut servir directement les fichiers.

## Migration Supabase

Exécuter la migration incluse :

`supabase/migrations/20260831203126_hero_local_media_metadata.sql`

Elle ajoute les métadonnées locales (`file_name`, `mime_type`, `file_size`) et une limite DB de 50 Mo.

## Limites médias

- JPG / PNG / WebP : 8 Mo maximum
- MP4 / WebM : 50 Mo maximum

Le code contrôle le MIME, l'extension et la signature binaire réelle du fichier.

## Déploiement

Après remplacement des fichiers :

```bash
npm run build
pm2 restart darlamamy
```

## Correctifs importants inclus

- suppression de la dépendance Supabase Storage pour les nouveaux médias Hero ;
- validation locale stricte des URLs lors des créations/remplacements ;
- HTTP 413 explicite pour les fichiers dépassant les limites ;
- message d'erreur 413 indiquant de vérifier Nginx ;
- correction du support des requêtes HTTP Range pour les vidéos ;
- correction du mode `static` dans le Hero frontend ;
- correction d'une accolade surnuméraire dans `Hero.tsx` qui pouvait casser le build ;
- valeurs par défaut Dar LaMamy / Fès dans l'admin ;
- fichiers stockés en 0644 et dossiers en 0755 pour permettre le service direct par Nginx.
